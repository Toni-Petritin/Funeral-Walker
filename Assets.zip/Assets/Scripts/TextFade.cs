using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextFade : MonoBehaviour
{
    public float timeToFade;

    //This just fades the text out after the given time.
    void Start()
    {
        GetComponent<Text>().CrossFadeAlpha(0.0f, timeToFade, false);
    }

}
