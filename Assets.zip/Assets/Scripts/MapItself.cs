using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapItself : MonoBehaviour
{
    public BiomePreset[] biomes;
    public GameObject tilePrefab;

    [Header("Dimensions")]
    public int width = 50;
    public int height = 50;
    public Vector2 offset;

    [Header("Height Map")]
    public Wave[] heightWaves;
    public float[,] heightMap;

    [Header("Moisture Map")]
    public Wave[] moistureWaves;
    public float[,] moistureMap;

    [Header("Heat Map")]
    public Wave[] heatWaves;
    public float[,] heatMap;

    public int[,] lifeMap;
    private float specialChance;
    
    void Start()
    {
        lifeMap = new int[width, height];
        GenerateMap();
    }

    void GenerateMap()
    {
        //Height map.
        heightMap = NoiseGenerator.Generate(width, height, heightWaves, offset);

        //Moisture map.
        moistureMap = NoiseGenerator.Generate(width, height, moistureWaves, offset);

        //Heat map.
        heatMap = NoiseGenerator.Generate(width, height, heatWaves, offset);

        for(int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                int rng = Random.Range(0, 100);
                specialChance = GetBiome(heightMap[x, y], moistureMap[x, y], heatMap[x, y]).specialChance;

                GameObject tile = Instantiate(tilePrefab, new Vector3(x, y, 0), Quaternion.identity);
                tile.GetComponent<SpriteRenderer>().sprite = GetBiome(heightMap[x, y], moistureMap[x, y], heatMap[x, y]).GetTileSprite();
                //These are the special tiles, which currently just replace the normal ones from ^^ there.
                //I wanted them to go on top as additional sprites, but I didn't have the patience to research how to do that.
                //So, this is a bandaid solution.
                if (rng < specialChance)
                {
                    tile.GetComponent<SpriteRenderer>().sprite = GetBiome(heightMap[x, y], moistureMap[x, y], heatMap[x, y]).GetSpecial();
                }

                //I tried to think of a more elegant way of referencing lifeMinus value, but failed sadly.
                lifeMap[x, y] = GetBiome(heightMap[x, y], moistureMap[x, y], heatMap[x, y]).lifeMinus;
            }

        }

    }

    //We use this to get a biome that meets the conditions of the noise functions the best.
    BiomePreset GetBiome(float height, float moisture, float heat)
    {
        List<BiomeTempData> biomeTemp = new List<BiomeTempData>();

        //This adds biomes to the list if they meet the minimum conditions of the biome.
        foreach(BiomePreset biome in biomes)
        {
            if(biome.MatchCondition(height, moisture, heat))
            {
                biomeTemp.Add(new BiomeTempData(biome));
            }
        }

        float curVal = 0.0f;
        BiomePreset biomeToReturn = null;
        
        //This part just compares the biome suitabilities with each other.
        //The process itself is explained below.
        foreach(BiomeTempData biome in biomeTemp)
        {
            if(biomeToReturn == null)
            {
                biomeToReturn = biome.biome;
                curVal = biome.GetDiffValue(height, moisture, heat);
            }
            else
            {
                if(biome.GetDiffValue(height, moisture, heat) < curVal)
                {
                    biomeToReturn = biome.biome;
                    curVal = biome.GetDiffValue(height, moisture, heat);
                }
            }
        }

        if(biomeToReturn == null)
        {
            biomeToReturn = biomes[0];
        }
        return biomeToReturn;
    }

    public class BiomeTempData
    {
        public BiomePreset biome;

        public BiomeTempData(BiomePreset preset)
        {
            biome = preset;
        }

        //What we are returning is the value of each condition combined minus the needed value.
        //This gives the most suited value for the biome.
        //This was used in the example code I used so I went with it,
        //but I'd likely have the height supersede the other values in a more complete game.
        public float GetDiffValue(float height, float moisture, float heat)
        {
            return (height - biome.minHeight) + (moisture - biome.minMoisture) + (heat - biome.minHeat);
        }

    }

}
