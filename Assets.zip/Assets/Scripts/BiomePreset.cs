using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

//The whole point of this is to allow easy creation of new biomes.
[CreateAssetMenu(fileName = "Biome Preset", menuName = "New Biome Preset")]
public class BiomePreset : ScriptableObject
{
    public Sprite[] tiles;
    public Sprite[] specials;
    public float minHeight;
    public float minMoisture;
    public float minHeat;
    public int lifeMinus;
    public float specialChance;

    //This allows several different variations of the same biome sprite to appear randomly.
    //I didn't end up using different variants as I went with single type sprites.
    public Sprite GetTileSprite()
    {
        return tiles[Random.Range(0, tiles.Length)];
    }

    //However, I did implement special tiles, which currently do nothing special other than look cool.
    public Sprite GetSpecial()
    {
        return specials[Random.Range(0, specials.Length)];
    }

    //This is used to check, if the noise function meets the requirements of the biome.
    public bool MatchCondition(float height, float moisture, float heat)
    {
        return height >= minHeight && moisture >= minMoisture && heat >= minHeat;
    }

    public int LifeReturn()
    {
        return lifeMinus;
    }

}
